def get_links():
    return ["https://t.me/zarko_tusic"]
